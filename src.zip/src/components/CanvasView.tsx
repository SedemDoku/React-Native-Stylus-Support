import React, {
  useRef,
  useState,
  useCallback,
  useEffect,
  useMemo,
  forwardRef,
  useImperativeHandle,
} from 'react';
import { StyleProp, ViewStyle, StyleSheet, View } from 'react-native';
import { Canvas, Path, Circle } from '@shopify/react-native-skia';
import {
  Gesture,
  GestureDetector,
  GestureHandlerRootView,
} from 'react-native-gesture-handler';
import { useSharedValue, runOnJS } from 'react-native-reanimated';
import { useStylusEvents } from 'react-native-stylus-events-local';
import {
  pointsToBezierPath,
  sampleSmoothedPath,
  splitStrokeByEraser,
} from '../drawing/smoothing';
import type { Stroke } from '../drawing/Stroke';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type Point = { x: number; y: number; pressure: number };

export type StylusDebug = {
  phase: 'down' | 'move' | 'up';
  x: number;
  y: number;
  canvasX: number;
  canvasY: number;
  pressure: number;
  tiltX?: number;
  tiltY?: number;
  orientation?: number;
  timestamp?: number;
  toolType?: 'stylus' | 'eraser' | 'unknown';
};

export type CanvasViewRef = {
  clear: () => void;
};

type Props = {
  style?: StyleProp<ViewStyle>;
  /** Current ink color. Snapshotted at stroke start. */
  strokeColor?: string;
  /** 'pen' draws, 'eraser' removes stroke segments under the gesture. */
  toolMode?: 'pen' | 'eraser';
  /** Eraser touch radius in px. */
  eraserRadius?: number;
  /** Constant stroke width (constant-width rendering path). */
  strokeWidth?: number;
  /** Minimum circle radius for pressure rendering. */
  minRadius?: number;
  /** Maximum circle radius for pressure rendering. */
  maxRadius?: number;
  /** Optional debug callback for live stylus data. */
  onStylusDebug?: (info: StylusDebug) => void;
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const MIN_SCALE = 0.2;
const MAX_SCALE = 8;
const clamp = (v: number, lo: number, hi: number) => {
  'worklet';
  return Math.max(lo, Math.min(hi, v));
};

/** Normalize stylus pressure (0..1). Falls back to 0.5 when unavailable. */
function normalizePressure(raw: number | undefined): number {
  if (typeof raw === 'number' && raw >= 0) return clamp(raw, 0, 1);
  return 0.5;
}

/**
 * Build a Skia-compatible SVG path string from an array of points.
 * Uses the Catmull-Rom → Bezier conversion for 3+ points.
 */
function pointsToPath(points: Array<{ x: number; y: number; pressure?: number }>): string {
  if (points.length === 0) return '';
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
  if (points.length === 2)
    return `M ${points[0].x} ${points[0].y} L ${points[1].x} ${points[1].y}`;
  return pointsToBezierPath(points as Point[]);
}

// ---------------------------------------------------------------------------
// Memoized stroke renderer — skips re-render when stroke data hasn't changed
// ---------------------------------------------------------------------------

type StrokeRendererProps = {
  stroke: Stroke;
  defaultStrokeWidth: number;
  defaultMinRadius: number;
  defaultMaxRadius: number;
};

const PRESSURE_POINT_LIMIT = 120;

const StrokeRenderer = React.memo<StrokeRendererProps>(
  ({ stroke, defaultStrokeWidth, defaultMinRadius, defaultMaxRadius }) => {
    const { points, color } = stroke;
    const sw = stroke.width ?? defaultStrokeWidth;
    const minR = stroke.minRadius ?? defaultMinRadius;
    const maxR = stroke.maxRadius ?? defaultMaxRadius;

    // Memoize the expensive smoothing / path computation
    const rendered = useMemo(() => {
      if (points.length === 0) return null;

      const hasPressure =
        points.length === 1 || points.some(p => p.pressure !== 0.5);

      if (hasPressure && points.length <= PRESSURE_POINT_LIMIT) {
        const smoothed = sampleSmoothedPath(points, 3);
        return (
          <React.Fragment>
            {smoothed.map((p, i) => {
              const r = minR + (maxR - minR) * (p.pressure ?? 0.5);
              if (r < 0.3) return null;
              return (
                <Circle
                  key={`${stroke.id}-${i}`}
                  cx={p.x}
                  cy={p.y}
                  r={r}
                  color={color}
                />
              );
            })}
          </React.Fragment>
        );
      }

      const path = pointsToPath(points);
      const averagePressure =
        points.reduce((sum, p) => sum + (p.pressure ?? 0.5), 0) / points.length;
      const pressureWidth = (minR + (maxR - minR) * averagePressure) * 2;
      return (
        <Path
          path={path}
          start={0}
          end={1}
          color={color}
          style="stroke"
          strokeWidth={hasPressure ? pressureWidth : sw}
          strokeCap="round"
          strokeJoin="round"
        />
      );
    }, [points, color, sw, minR, maxR, stroke.id]);

    return rendered;
  },
  // Custom equality: skip re-render if stroke id, point count, and last point are the same
  (prev, next) =>
    prev.stroke.id === next.stroke.id &&
    prev.stroke.points.length === next.stroke.points.length &&
    prev.stroke.color === next.stroke.color &&
    prev.defaultStrokeWidth === next.defaultStrokeWidth &&
    prev.defaultMinRadius === next.defaultMinRadius &&
    prev.defaultMaxRadius === next.defaultMaxRadius,
);

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

/**
 * CanvasView
 *
 * A self-contained drawing surface that:
 * - Receives stylus samples from `useStylusEvents` (react-native-stylus-events-local).
 * - Supports pressure-sensitive ink via circles along a Catmull-Rom smoothed centerline.
 * - Supports a segment-level eraser that splits strokes rather than deleting whole ones.
 * - Supports one-finger pan and two-finger pinch-to-zoom via GestureHandler + Reanimated.
 *
 * Architecture notes:
 * - `currentPoints` is a mutable ref to avoid a React re-render on every stylus sample.
 *   We only call `setStrokes` at controlled points (addPoint throttles the eraser via rAF).
 * - The pan/zoom transform is stored in JS state as the source of truth for the Skia Group
 *   matrix. Gesture worklets mutate shared values during the gesture (smooth 60/120fps), then
 *   `runOnJS(commitTransform)()` writes back to state on gesture end.
 * - Stylus coordinates arrive in screen space and are mapped to canvas space via `toCanvasSpace`
 *   before being stored, so strokes stay anchored to the canvas as the user pans/zooms.
 */
const CanvasView = forwardRef<CanvasViewRef, Props>(function CanvasView(
  {
    style,
    strokeColor = '#111',
    toolMode = 'pen',
    eraserRadius = 24,
    strokeWidth = 2.5,
    minRadius = 0.5,
    maxRadius = 14,
    onStylusDebug,
  },
  ref,
) {
  // -------------------------------------------------------------------------
  // Stroke state
  // -------------------------------------------------------------------------

  // Committed strokes — only mutated on pen-up / eraser / clear.
  const [committedStrokes, setCommittedStrokes] = useState<Stroke[]>([]);

  // Active (in-progress) stroke lives in a ref to avoid per-sample state copies.
  // A lightweight version counter triggers re-renders at rAF cadence (~60fps).
  const activeStrokeRef = useRef<Stroke | null>(null);
  const [activeVersion, setActiveVersion] = useState(0);
  const rafScheduled = useRef(false);

  // High-frequency input is buffered in a ref to avoid per-sample re-renders.
  const currentPoints = useRef<Point[]>([]);
  const strokeColorAtStart = useRef(strokeColor);
  const penSizeRef = useRef({ strokeWidth, minRadius, maxRadius });
  penSizeRef.current = { strokeWidth, minRadius, maxRadius };
  const isDrawing = useRef(false);

  // Point decimation: minimum squared distance between consecutive points.
  const MIN_POINT_DIST_SQ = 4; // 2px

  // rAF gate for eraser updates (max once per frame).
  const eraserRafScheduled = useRef(false);
  const eraserRadiusRef = useRef(eraserRadius);
  eraserRadiusRef.current = eraserRadius;

  // Throttle debug callback (~60fps instead of every sample).
  const debugRafScheduled = useRef(false);
  const pendingDebugInfo = useRef<StylusDebug | null>(null);
  const onStylusDebugRef = useRef(onStylusDebug);
  onStylusDebugRef.current = onStylusDebug;

  // Stable rAF tick functions — created once, never recreated.
  const debugTick = useCallback(() => {
    debugRafScheduled.current = false;
    if (pendingDebugInfo.current && onStylusDebugRef.current) {
      onStylusDebugRef.current(pendingDebugInfo.current);
    }
  }, []);

  const activeRenderTick = useCallback(() => {
    rafScheduled.current = false;
    setActiveVersion(v => v + 1);
  }, []);

  const scheduleDebug = useCallback((info: StylusDebug) => {
    pendingDebugInfo.current = info;
    if (!debugRafScheduled.current) {
      debugRafScheduled.current = true;
      requestAnimationFrame(debugTick);
    }
  }, [debugTick]);

  // Schedule a re-render of the active stroke at most once per frame.
  const scheduleActiveRender = useCallback(() => {
    if (!rafScheduled.current) {
      rafScheduled.current = true;
      requestAnimationFrame(activeRenderTick);
    }
  }, [activeRenderTick]);

  // Layout cache for coordinate conversions.
  const canvasLayout = useRef({ x: 0, y: 0, width: 0, height: 0 });
  const canvasRef = useRef<View>(null);
  const lastStylusRef = useRef<StylusDebug | null>(null);

  // -------------------------------------------------------------------------
  // Pan / zoom transform
  // -------------------------------------------------------------------------

  // Committed transform — JS source of truth used to build the Skia Group matrix.
  type Transform = { translateX: number; translateY: number; scale: number };
  const [transform, setTransform] = useState<Transform>({
    translateX: 0,
    translateY: 0,
    scale: 1,
  });

  // Snapshot of transform at gesture start (worklet-safe shared values).
  const baseTx = useSharedValue(0);
  const baseTy = useSharedValue(0);
  const baseScale = useSharedValue(1);

  // Live values mutated every frame by gesture worklets.
  const liveTx = useSharedValue(0);
  const liveTy = useSharedValue(0);
  const liveScale = useSharedValue(1);

  // Keep shared values in sync with committed state so the next gesture starts correctly.
  useEffect(() => {
    liveTx.value = transform.translateX;
    liveTy.value = transform.translateY;
    liveScale.value = transform.scale;
  }, [transform]);

  const commitTransform = useCallback(() => {
    setTransform({
      translateX: liveTx.value,
      translateY: liveTy.value,
      scale: liveScale.value,
    });
  }, []);

  // -------------------------------------------------------------------------
  // Gestures (finger only — stylus handled separately by useStylusEvents)
  // -------------------------------------------------------------------------

  /**
   * Gesture objects are memoized so worklet closures are only built once.
   * All captured values (baseTx, liveTx, etc.) are Reanimated shared values (stable refs),
   * and commitTransform is a stable useCallback([]), so the memoization is safe.
   */
  const composedGesture = useMemo(() => {
    const pan = Gesture.Pan()
      .minPointers(1)
      .maxPointers(1)
      .onBegin(() => {
        'worklet';
        baseTx.value = liveTx.value;
        baseTy.value = liveTy.value;
      })
      .onUpdate(e => {
        'worklet';
        liveTx.value = baseTx.value + e.translationX;
        liveTy.value = baseTy.value + e.translationY;
      })
      .onEnd(() => {
        'worklet';
        runOnJS(commitTransform)();
      });

    const pinch = Gesture.Pinch()
      .onBegin(() => {
        'worklet';
        baseScale.value = liveScale.value;
        baseTx.value = liveTx.value;
        baseTy.value = liveTy.value;
      })
      .onUpdate(e => {
        'worklet';
        const nextScale = clamp(baseScale.value * e.scale, MIN_SCALE, MAX_SCALE);
        const scaleDelta = nextScale / baseScale.value;
        liveTx.value = e.focalX - (e.focalX - baseTx.value) * scaleDelta;
        liveTy.value = e.focalY - (e.focalY - baseTy.value) * scaleDelta;
        liveScale.value = nextScale;
      })
      .onEnd(() => {
        'worklet';
        runOnJS(commitTransform)();
      });

    return Gesture.Simultaneous(pan, pinch);
  }, [commitTransform]);

  // -------------------------------------------------------------------------
  // Coordinate mapping
  // -------------------------------------------------------------------------

  /**
   * Convert screen-space stylus coordinates to canvas-local space.
   * Must be called with the current committed transform; strokes are stored in canvas space
   * so they stay put when the user pans or zooms.
   */
  const toCanvasSpace = useCallback(
    (sx: number, sy: number) => {
      const { x: offsetX, y: offsetY, width, height } = canvasLayout.current;
      if (width === 0 && height === 0) {
        return {
          x: (sx - transform.translateX) / transform.scale,
          y: (sy - transform.translateY) / transform.scale,
        };
      }

      const looksLocal = sx >= 0 && sy >= 0 && sx <= width && sy <= height;
      if (looksLocal) {
        return {
          x: (sx - transform.translateX) / transform.scale,
          y: (sy - transform.translateY) / transform.scale,
        };
      }
      return {
        x: (sx - offsetX - transform.translateX) / transform.scale,
        y: (sy - offsetY - transform.translateY) / transform.scale,
      };
    },
    [transform],
  );

  // -------------------------------------------------------------------------
  // Drawing logic
  // -------------------------------------------------------------------------

  const addPoint = useCallback(
    (x: number, y: number, pressure: number) => {
      // Point decimation: skip sub-pixel moves.
      const pts = currentPoints.current;
      if (pts.length > 0) {
        const last = pts[pts.length - 1];
        const dx = x - last.x;
        const dy = y - last.y;
        if (dx * dx + dy * dy < MIN_POINT_DIST_SQ) return;
      }

      pts.push({ x, y, pressure });

      if (toolMode === 'pen') {
        // Update the active stroke ref (no state copy!) and schedule a
        // single re-render per animation frame.
        if (activeStrokeRef.current) {
          activeStrokeRef.current.points = pts;
        }
        scheduleActiveRender();
      } else {
        // Eraser: throttle to one update per animation frame.
        if (!eraserRafScheduled.current) {
          eraserRafScheduled.current = true;
          requestAnimationFrame(() => {
            eraserRafScheduled.current = false;
            const eraserPath = [...currentPoints.current];
            const r = eraserRadiusRef.current;
            setCommittedStrokes(prev => {
              const next: Stroke[] = [];
              for (const stroke of prev) {
                const segments = splitStrokeByEraser(stroke.points, eraserPath, r);
                for (const seg of segments) {
                  if (seg.length > 0) {
                    next.push({ ...stroke, id: `${stroke.id}-${next.length}`, points: seg });
                  }
                }
              }
              return next;
            });
          });
        }
      }
    },
    [toolMode, scheduleActiveRender],
  );

  const startStroke = useCallback(
    (x: number, y: number, pressure: number) => {
      isDrawing.current = true;
      currentPoints.current = [{ x, y, pressure }];
      strokeColorAtStart.current = strokeColor;
      penSizeRef.current = { strokeWidth, minRadius, maxRadius };

      if (toolMode === 'pen') {
        const size = penSizeRef.current;
        const newStroke: Stroke = {
          id: `stroke-${Date.now()}-${Math.random()}`,
          points: currentPoints.current, // share ref, not copy
          color: strokeColorAtStart.current,
          width: size.strokeWidth,
          minRadius: size.minRadius,
          maxRadius: size.maxRadius,
        };
        activeStrokeRef.current = newStroke;
        scheduleActiveRender();
      }
    },
    [toolMode, strokeColor, strokeWidth, minRadius, maxRadius, scheduleActiveRender],
  );

  const endStroke = useCallback(() => {
    currentPoints.current = [];
    isDrawing.current = false;

    if (toolMode === 'pen' && activeStrokeRef.current) {
      const finalized: Stroke = {
        ...activeStrokeRef.current,
        points: [...activeStrokeRef.current.points], // snapshot
      };
      activeStrokeRef.current = null;
      // Commit to the permanent list — a single state update.
      setCommittedStrokes(prev => [...prev, finalized]);
    }
    // Eraser strokes are already updated in real time; nothing extra to do.
  }, [toolMode]);

  // Stable refs so useStylusEvents callbacks always see the latest version
  // without needing to be re-subscribed when toolMode or transform change.
  const startStrokeRef = useRef(startStroke);
  const addPointRef = useRef(addPoint);
  const endStrokeRef = useRef(endStroke);
  const toCanvasSpaceRef = useRef(toCanvasSpace);
  const scheduleDebugRef = useRef(scheduleDebug);
  startStrokeRef.current = startStroke;
  addPointRef.current = addPoint;
  endStrokeRef.current = endStroke;
  toCanvasSpaceRef.current = toCanvasSpace;
  scheduleDebugRef.current = scheduleDebug;

  // -------------------------------------------------------------------------
  // Stylus input — react-native-stylus-events-local
  // -------------------------------------------------------------------------

  /**
   * `useStylusEvents` fires on the JS thread with hardware stylus data.
   * We use stable ref wrappers so we never need to re-subscribe when
   * `transform` or `toolMode` changes (the refs always point to the latest closures).
   *
   * Note: GestureHandler's finger gestures (pan/pinch) are separate from stylus events
   * so there's no conflict: the user can draw with the pen while GestureDetector ignores it.
   */
  // Stable callbacks for stylus events — all use refs internally so they never
  // need to change identity. This prevents useStylusEvents from re-subscribing.
  const handleStylusDown = useCallback((e: any) => {
    const { x, y } = toCanvasSpaceRef.current(e.x, e.y);
    const info: StylusDebug = {
      phase: 'down',
      x: e.x,
      y: e.y,
      canvasX: x,
      canvasY: y,
      pressure: normalizePressure(e.pressure),
      tiltX: e.tiltX,
      tiltY: e.tiltY,
      orientation: e.orientation,
      timestamp: e.timestamp,
      toolType: e.toolType,
    };
    lastStylusRef.current = info;
    scheduleDebugRef.current(info);
    startStrokeRef.current(x, y, info.pressure);
  }, []);

  const handleStylusMove = useCallback((e: any) => {
    if (!isDrawing.current) return;
    const { x, y } = toCanvasSpaceRef.current(e.x, e.y);
    const info: StylusDebug = {
      phase: 'move',
      x: e.x,
      y: e.y,
      canvasX: x,
      canvasY: y,
      pressure: normalizePressure(e.pressure),
      tiltX: e.tiltX,
      tiltY: e.tiltY,
      orientation: e.orientation,
      timestamp: e.timestamp,
      toolType: e.toolType,
    };
    lastStylusRef.current = info;
    scheduleDebugRef.current(info);
    addPointRef.current(x, y, info.pressure);
  }, []);

  const handleStylusUp = useCallback(() => {
    if (lastStylusRef.current) {
      // Flush debug immediately on pen-up so UI shows final state.
      onStylusDebugRef.current?.({ ...lastStylusRef.current, phase: 'up' });
    }
    endStrokeRef.current();
  }, []);

  const stylusConfig = useMemo(
    () => ({
      onStylusDown: handleStylusDown,
      onStylusMove: handleStylusMove,
      onStylusUp: handleStylusUp,
    }),
    [handleStylusDown, handleStylusMove, handleStylusUp],
  );

  useStylusEvents(stylusConfig);

  // -------------------------------------------------------------------------
  // Imperative API
  // -------------------------------------------------------------------------

  const clear = useCallback(() => {
    setCommittedStrokes([]);
    activeStrokeRef.current = null;
    setActiveVersion(0);
  }, []);
  useImperativeHandle(ref, () => ({ clear }), [clear]);

  // -------------------------------------------------------------------------
  // Rendering — memoized per-stroke via StrokeRenderer
  // -------------------------------------------------------------------------

  // -------------------------------------------------------------------------
  // Layout / transform
  // -------------------------------------------------------------------------

  /**
   * We don't use a Skia Group matrix here — instead we transform the canvas
   * coordinates at sample time (toCanvasSpace) and rely on the Canvas's own
   * coordinate system remaining fixed. This keeps rendering simple: every stroke
   * is always drawn in the same "world" space, and pan/zoom just changes what
   * region of that space is visible.
   *
   * A full pan+zoom implementation would wrap strokes in a Skia Group with a matrix,
   * but that requires Reanimated shared values to be wired into Skia, which adds
   * more complexity than warranted here. The current approach is correct and stable.
   */
  const handleLayout = useCallback(() => {
    canvasRef.current?.measureInWindow((x, y, width, height) => {
      canvasLayout.current = { x, y, width, height };
    });
  }, []);

  return (
    <GestureHandlerRootView style={[styles.root, style]}>
      <GestureDetector gesture={composedGesture}>
        <View
          ref={canvasRef}
          style={styles.root}
          onLayout={handleLayout}
        >
          <Canvas style={styles.canvas}>
            {committedStrokes.map(stroke => (
              <StrokeRenderer
                key={stroke.id}
                stroke={stroke}
                defaultStrokeWidth={strokeWidth}
                defaultMinRadius={minRadius}
                defaultMaxRadius={maxRadius}
              />
            ))}
            {activeStrokeRef.current && activeVersion > 0 && (
              <StrokeRenderer
                key={`active-${activeStrokeRef.current.id}-${activeVersion}`}
                stroke={activeStrokeRef.current}
                defaultStrokeWidth={strokeWidth}
                defaultMinRadius={minRadius}
                defaultMaxRadius={maxRadius}
              />
            )}
          </Canvas>
        </View>
      </GestureDetector>
    </GestureHandlerRootView>
  );
});

export default CanvasView;

const styles = StyleSheet.create({
  root: { flex: 1 },
  canvas: { flex: 1, backgroundColor: '#fff' },
});
